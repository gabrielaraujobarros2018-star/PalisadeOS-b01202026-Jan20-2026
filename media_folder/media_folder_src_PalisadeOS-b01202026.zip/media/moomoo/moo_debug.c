#include <stdint.h>

void moo_debug(void) {
}

void moo_debug_value(int v) {
    (void)v;
}

void moo_debug_init(void) {
}