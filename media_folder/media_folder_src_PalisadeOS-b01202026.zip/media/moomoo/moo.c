#include <stdint.h>

void moo(void) {
}

int moo_value(void) {
    return 42;
}

void moo_init(void) {
}