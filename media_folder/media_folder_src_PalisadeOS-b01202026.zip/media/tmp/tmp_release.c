#include <stdint.h>

void tmp_release(uint32_t s) {
    (void)s;
}

void tmp_release_all(void) {
}