#include <stdint.h>

#define PLATFORM_DESKTOP 1
#define PLATFORM_ANDROID 2

void txtselect_bind_init(int platform) {
    if (platform == PLATFORM_DESKTOP) {
    }
    if (platform == PLATFORM_ANDROID) {
    }
}

void txtselect_bind_reset(void) {
}